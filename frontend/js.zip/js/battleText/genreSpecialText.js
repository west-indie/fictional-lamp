// frontend/js/battleText/genreSpecialText.js
//
// Step B — centralized genre-special narration templates + ordering.
// DATA ONLY. No combat math.
//
// Template vars:
// {actor} {move} {target}
// {dmg} {teamDmg} {teamHeal} {heal}
//
// Duration phrase vars (already include "for X turn(s)"):
// {buffTurnsPhrase} {debuffTurnsPhrase} {shieldTurnsPhrase} {drTurnsPhrase}

export const GENRE_SPECIAL_TEXT = {
  DEFAULT: {
    fallback: "[DEV] Missing genreSpecialText entry for this genre.",
    order: ["fallback"],
    phase: { fallback: "postFx" }
  },

  // ACTION: self ATK buff + immediate hit
  ACTION: {
    atkUp: "{actor}'s ATTACK rises {buffTurnsPhrase}.",
    onHit: "{actor} attacks for {dmg} damage.",
    order: ["atkUp", "onHit"]
  },

  // ADVENTURE: team ATK + team DEF buffs + TEAM STRIKE
  ADVENTURE: {
    teamAtkUp: "The team's ATTACK rises {buffTurnsPhrase}.",
    teamDefUp: "The team's DEFENSE rises {buffTurnsPhrase}.",
    teamStrike: "{actor} calls the team together to hit for {teamDmg} total damage!",
    order: ["teamAtkUp", "teamDefUp", "teamStrike"]
  },

  // DRAMA: self heal (max HP %) + self DEF buff
  DRAMA: {
    defUp: "{actor}'s DEFENSE rises {buffTurnsPhrase}.",
    selfHeal: "{actor} also heals {heal} HP.",
    order: ["defUp", "selfHeal"]
  },

  // COMEDY: enemy ATK debuff + team DEF buff + team heal
  COMEDY: {
    enemyAtkDown: "Enemy ATTACK falls {debuffTurnsPhrase}.",
    teamDefUp: "The team's DEFENSE rises {buffTurnsPhrase}.",
    teamHeal: "The team also heals {teamHeal} total HP.",
    order: ["enemyAtkDown", "teamDefUp", "teamHeal"]
  },

  // HORROR: pre-hit boost implied (no ATK line) + hit + enemy DEF debuff
  HORROR: {
    onHit: "It hits for {dmg} damage.",
    enemyDefDown: "Enemy DEFENSE falls {debuffTurnsPhrase}.",
    order: ["onHit", "enemyDefDown"]
  },

  // THRILLER: next-hit vulnerability (no immediate damage)
  THRILLER: {
    expose: "The enemy is exposed until the next hit.",
    order: ["expose"]
  },

  // MYSTERY: enemy DEF debuff; optional ATK debuff (primary only)
  MYSTERY: {
    enemyDefDown: "Enemy DEFENSE falls {debuffTurnsPhrase}.",
    enemyAtkDown: "Enemy ATTACK falls {debuffTurnsPhrase}.",
    order: ["enemyDefDown", "enemyAtkDown"]
  },

  // SCIFI: self ATK buff + self DEF debuff + immediate hit
  SCIFI: {
    atkUp: "{actor}'s ATTACK rises {buffTurnsPhrase}.",
    selfDefDown: "{actor}'s DEFENSE falls {debuffTurnsPhrase}.",
    onHit: "{actor} attacks for {dmg} damage.",
    order: ["atkUp", "selfDefDown", "onHit"]
  },

  // FANTASY: ally shield (no shield number)
  FANTASY: {
    allyShield: "{target} is shielded {shieldTurnsPhrase}.",
    order: ["allyShield"]
  },

  // ANIMATION: team damage reduction + optional immediate hit (primary only)
  ANIMATION: {
    onHit: "{actor} uses this new freedom to hit for {dmg} damage.",
    damageReduction: "The team also takes less damage {drTurnsPhrase}.",
    order: ["onHit", "damageReduction"]
  },

  // CRIME: enemy ATK debuff + enemy DEF debuff; secondary may also do an immediate hit
  CRIME: {
    enemyAtkDown: "Enemy ATTACK falls {debuffTurnsPhrase}.",
    enemyDefDown: "Enemy DEFENSE falls {debuffTurnsPhrase}.",
    onHit: "{actor} breaks {target}'s legs.",
    order: ["enemyAtkDown", "enemyDefDown", "onHit"]
  },

  // ROMANCE: ally heal
  ROMANCE: {
    allyHeal: "{target} heals {heal} HP.",
    order: ["allyHeal"]
  },

  // MUSICAL: team ATK buff (1T) + team heal + TEAM STRIKE
  MUSICAL: {
    teamHeal: "The team heals {teamHeal} total HP.",
    teamAtkUp: "The team's ATTACK rises {buffTurnsPhrase}.",
    teamStrike: "The team bands together to hit for {teamDmg} total damage!",
    order: [ "teamHeal", "teamAtkUp", "teamStrike"]
  },

  // DOCUMENTARY: enemy ATK+DEF debuffs; secondary may also do an immediate hit
  DOCUMENTARY: {
    onHit: "It hits for {dmg} damage.",
    enemyAtkDown: "Enemy ATTACK falls {debuffTurnsPhrase}.",
    enemyDefDown: "Enemy DEFENSE falls {debuffTurnsPhrase}.",
    order: ["onHit", "enemyAtkDown", "enemyDefDown"]
  }
};
