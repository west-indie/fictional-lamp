// frontend/js/battleText/buildSpecialLines.js
//
// Step B — build final message-box lines for a Special.
//
// - Execution returns { used, effects, error, meta } (no strings)
// - Narration happens AFTER execution
// - ✅ If SIGNATURE_EFFECT_TEXT has an entry for this special.key:
//     we do FULL OVERRIDE (only the authored lines are shown).

import { buildGenreSpecialLines } from "./genreSpecialNarration.js";
import { buildSignatureSpecialLines } from "./signatureSpecialNarration.js";
import { SIGNATURE_EFFECT_TEXT } from "./signatureEffectText.js";
import { deriveMarkersFromEffects } from "./targets.js";
import { auditEffectKeys } from "./auditEffectKeys.js";

function safeTitle(x) {
  const t = x?.movie?.title || x?.title || x?.name || "Actor";
  return String(t).slice(0, 30);
}

function asArray(v) {
  if (typeof v === "string" && v.trim()) return [v.trim()];
  if (Array.isArray(v)) return v.filter(Boolean).map((s) => String(s)).filter(Boolean);
  return [];
}

function renderTemplate(str, vars) {
  return String(str || "").replace(/\{(\w+)\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : `{${k}}`));
}

/**
 * FULL override rendering:
 * - Renders intro/outro arrays (if present)
 * - Renders effectText in OBJECT INSERTION ORDER,
 *   but only for effect keys that exist in result.effects.
 * - Uses {value} for that effect key's value.
 */
function buildFullOverrideLines({ override, vars, effects }) {
  const lines = [];

  const introLines = asArray(override?.intro).map((tpl) => renderTemplate(tpl, vars));
  const outroLines = asArray(override?.outro).map((tpl) => renderTemplate(tpl, vars));

  // If no authored intro, keep a safe default headline.
  if (introLines.length > 0) lines.push(...introLines);
  else lines.push(`${vars.actor} uses ${vars.move}!`);

  // If showEffects is explicitly false, skip effectText entirely.
  const showEffects = override?.showEffects !== false;

  if (showEffects && override?.effectText && typeof override.effectText === "object") {
    for (const key of Object.keys(override.effectText)) {
      if (!Object.prototype.hasOwnProperty.call(effects || {}, key)) continue;

      const raw = effects[key];
      const value =
        typeof raw === "number" ? raw : raw == null ? "" : String(raw);

      const tpls = asArray(override.effectText[key]);
      for (const tpl of tpls) {
        const line = renderTemplate(tpl, { ...vars, value });
        if (line) lines.push(line);
      }
    }
  }

  if (outroLines.length > 0) lines.push(...outroLines);

  // Safety: never empty
  if (lines.length === 0) lines.push(`${vars.actor} uses ${vars.move}!`);

  return lines.filter(Boolean);
}

function buildErrorLines({ actorName, moveName, error }) {
  if (!error || typeof error !== "object") return ["Nothing happens."];
  if (error.code === "noActor") return ["No valid actor."];
  if (error.code === "noSpecial") return ["No special selected."];
  if (error.code === "cooldown") {
    const cd = Number(error.cooldownTurns || 0);
    return [`${moveName} is on cooldown (${cd} turn${cd === 1 ? "" : "s"}).`];
  }
  if (error.code === "noAllyTarget") return ["No valid ally targets."];
  if (error.code === "invalidTarget") return ["Invalid target."];
  return [`${actorName} can't use that right now.`];
}

/**
 * Build final lines for UI.
 */
export function buildSpecialLines({ actor, party, enemy, special, targetIndex, result }) {
  const actorName = safeTitle(actor);
  const moveName = String(special?.name || "Special");
  const enemyName = safeTitle(enemy) || "the enemy";

  const metaTargetName =
    result?.meta?.targetName != null && String(result.meta.targetName).trim()
      ? String(result.meta.targetName).slice(0, 30)
      : "";

  const targetName =
    metaTargetName ||
    (typeof targetIndex === "number" && Array.isArray(party) && party[targetIndex]
      ? safeTitle(party[targetIndex])
      : "ally");

  if (!result?.used) {
    return buildErrorLines({ actorName, moveName, error: result?.error });
  }

  // Validate marker pipeline (even if caller uses it elsewhere)
  deriveMarkersFromEffects(result.effects);
  auditEffectKeys(result.effects, `special:${special?.key || special?.id || moveName}`);

  // ✅ FULL OVERRIDE PATH (signatureEffectText)
  const override = SIGNATURE_EFFECT_TEXT?.[special?.key] || null;
  if (override && typeof override === "object") {
    const vars = {
      actor: actorName,
      move: moveName,
      target: targetName,
      enemy: enemyName
    };

    // (Optional) keep this — useful to tag "override" in logs
    auditEffectKeys(result.effects || {}, `override:${special?.key || special?.id || moveName}`);

    return buildFullOverrideLines({ override, vars, effects: result.effects || {} });
  }


  // ----- Base narration (genre vs signature) -----
  if (special?.source === "genre") {
    return buildGenreSpecialLines({
      genre: special.genre,
      actor: actorName,
      move: moveName,
      target: targetName,
      outcome: result.effects || {}
    });
  }

  // ✅ Signature narration
  // dualEffect execution stores ordered steps at result.meta.stepResults (per your specialSystem.js).
  const stepResults = Array.isArray(result?.meta?.stepResults) ? result.meta.stepResults : null;

if (stepResults && stepResults.length > 0) {
  const lines = [];

  for (let i = 0; i < stepResults.length; i++) {
    const step = stepResults[i];
    if (!step) continue;

    // ✅ Phase 3 audit: capture step-level effects too
    auditEffectKeys(
      step.effects || {},
      `dualStep:${special?.key || special?.id || moveName}:#${i}:${step.kind || "unknown"}`
    );

    const stepKind = step.kind || null;

    const stepTargetName =
      step?.meta?.targetName != null && String(step.meta.targetName).trim()
        ? String(step.meta.targetName).slice(0, 30)
        : targetName;

    // Tiny “step special” shell so signature narration can infer target/team etc.
    const stepSpecial = {
      kind: stepKind,
      sigKind: stepKind,
      target: step.target ?? null
    };

    const stepLines = buildSignatureSpecialLines({
      special: stepSpecial,
      actor: actorName,
      move: moveName,
      target: stepTargetName,
      enemy: enemyName,
      effects: step.effects || null,
      outcome: null,
      kind: stepKind,
      key: null,
      movieId: result?.meta?.movieId || null,
      inlineText: null,

      // ✅ intro ONLY on first step (prevents duplication forever)
      includeIntro: i === 0
    });

    for (const ln of stepLines) if (ln) lines.push(ln);
  }

  return lines.filter(Boolean);
}

  // Normal single-effect signature
  auditEffectKeys(result.effects || {}, `sig:${special?.key || special?.id || moveName}`);

  return buildSignatureSpecialLines({
    special,
    actor: actorName,
    move: moveName,
    target: targetName,
    enemy: enemyName,
    effects: result.effects || null,
    outcome: null,
    key: special.key || null,
    movieId: result?.meta?.movieId || null
  });
}
