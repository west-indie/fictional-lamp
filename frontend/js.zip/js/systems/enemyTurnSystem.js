// frontend/js/systems/enemyTurnSystem.js
//
// Replacement: supports the NEW specials system status effects.
//
// Implements:
// - Enemy ATK debuffs (e.g., Comedy/Mystery/Crime/Documentary) via enemy.statuses.atkDebuffPct
// - Party DEF buffs/debuffs via target.statuses.defBuffPct / target.statuses.defDebuffPct
// - Team/actor damage reduction via target.statuses.damageReductionPct
// - Temporary shields via target.tempShield
// - NEW: generic STATUS support (e.g., stun) via enemy.statuses.stunTurns
//
// NOTE:
// This file does not decrement status durations. (You’ll tick turns elsewhere—typically at the
// start of each actor’s turn or at round boundaries.) This only *applies* the current modifiers.

import { enemyMoves } from "../data/enemyMoves.js";
import { computeEnemyAttack } from "./damageSystem.js";
import { getAliveParty } from "./turnSystem.js";

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function getFallbackMove() {
  return (
    enemyMoves.basic_attack || {
      id: "basic_attack",
      name: "Attack",
      kind: "attack",
      powerMultiplier: 1.0,
      weight: 1
    }
  );
}

function pickWeightedMove(moveIds) {
  const defs = (moveIds || []).map((id) => enemyMoves[id]).filter(Boolean);
  if (defs.length === 0) return getFallbackMove();

  const total = defs.reduce((sum, m) => sum + (m.weight ?? 1), 0);
  let roll = Math.random() * total;

  for (const m of defs) {
    roll -= (m.weight ?? 1);
    if (roll <= 0) return m;
  }

  return defs[defs.length - 1] || getFallbackMove();
}

function getActionsPerTurn(enemy) {
  const apt = enemy?.actionsPerTurn;

  if (typeof apt === "number") {
    return clamp(Math.floor(apt), 1, 4);
  }

  if (apt && typeof apt === "object") {
    const min = clamp(Math.floor(apt.min ?? 1), 1, 4);
    const max = clamp(Math.floor(apt.max ?? min), min, 4);
    const rolled = min + Math.floor(Math.random() * (max - min + 1));
    return clamp(rolled, 1, 4);
  }

  return 1;
}

function pickRandomAliveTarget(party) {
  const alive = getAliveParty(party);
  if (alive.length === 0) return null;
  return alive[Math.floor(Math.random() * alive.length)];
}

function getStatusPct(obj, key) {
  // status keys used by specialSystem.js:
  // - atkDebuffPct / atkDebuffTurns
  // - defBuffPct / defBuffTurns
  // - defDebuffPct / defDebuffTurns
  // - damageReductionPct / damageReductionTurns
  const s = obj?.statuses;
  if (!s) return 0;

  const turnsKey = key.replace("Pct", "Turns");
  const turns = s[turnsKey];

  // If turns exist and are 0 or less, treat as expired.
  if (typeof turns === "number" && turns <= 0) return 0;

  return Number(s[key] ?? 0) || 0;
}

function getStatusTurns(obj, turnsKey) {
  const s = obj?.statuses;
  if (!s) return 0;
  const t = Number(s[turnsKey] ?? 0) || 0;
  return Math.max(0, Math.floor(t));
}

export function runEnemyTurn(enemy, party, { funnyDisrupt = false } = {}) {
  const aliveNow = getAliveParty(party);
  if (aliveNow.length === 0) {
    return { lines: ["Your party has fallen..."], partyDefeated: true };
  }

  // Funny tone disrupts enemy turn (your existing mechanic)
  if (funnyDisrupt) {
    return {
      lines: ["The enemy is thrown off by your party's comedy! Their turn fails."],
      partyDefeated: false
    };
  }

  // ✅ NEW: Stun support (status system writes enemy.statuses.stunTurns)
  // This system does NOT decrement durations; it only checks them.
  const stunTurns = getStatusTurns(enemy, "stunTurns");
  if (stunTurns > 0) {
    return {
      lines: [`${enemy.name} is stunned and can't act!`],
      partyDefeated: false
    };
  }

  // ✅ NEW: Dazed support (enemy can act, but is less accurate + hits softer)
  // - Miss chance is handled here
  // - Reduced hit is applied by scaling enemy's effective ATK before computeEnemyAttack()
  const dazedTurns = getStatusTurns(enemy, "dazedTurns");
  const isDazed = dazedTurns > 0;

  // Tunables (keep here for Phase 3; can move to constants later)
  const DAZED_MISS_CHANCE = 0.35; // 35% chance to miss while dazed
  const DAZED_DAMAGE_MULT = 0.75; // 25% reduced hit while dazed

  const actions = getActionsPerTurn(enemy);
  const moveIds = enemy?.moves || ["basic_attack"];
  const lines = [];

  for (let i = 0; i < actions; i++) {
    const alive = getAliveParty(party);
    if (alive.length === 0) return { lines, partyDefeated: true };

    const target = pickRandomAliveTarget(party);
    if (!target) return { lines, partyDefeated: true };

    const move = pickWeightedMove(moveIds);

    if (move.kind !== "attack") {
      lines.push(`${enemy.name} tries something strange...`);
      continue;
    }

    // ✅ If dazed, enemy may miss entirely
    if (isDazed && Math.random() < DAZED_MISS_CHANCE) {
      lines.push(`${enemy.name} uses ${move.name}... but they look dazed and miss!`);
      continue;
    }

    // ---- Apply NEW SPECIAL SYSTEM MODIFIERS (temporarily) ----
    const originalEnemyAtk = Number(enemy.attack ?? 1) || 1;
    const originalTargetDef = Number(target.def ?? 0) || 0;

    // Apply move multiplier first
    const mult = Number(move.powerMultiplier ?? 1.0) || 1.0;
    let effectiveEnemyAtk = Math.max(1, Math.round(originalEnemyAtk * mult));

    // Enemy ATK debuff from statuses (Comedy/Mystery/etc.)
    const enemyAtkDebuffPct = clamp(getStatusPct(enemy, "atkDebuffPct"), 0, 0.9);
    if (enemyAtkDebuffPct > 0) {
      effectiveEnemyAtk = Math.max(1, Math.round(effectiveEnemyAtk * (1 - enemyAtkDebuffPct)));
    }

    // ✅ Dazed reduces the hit (softer control than stun)
    if (isDazed) {
      effectiveEnemyAtk = Math.max(1, Math.round(effectiveEnemyAtk * DAZED_DAMAGE_MULT));
    }

    // Target DEF buffs/debuffs from statuses (Comedy/Adventure, Sci-Fi penalty, etc.)
    const defBuffPct = clamp(getStatusPct(target, "defBuffPct"), 0, 2.0);
    const defDebuffPct = clamp(getStatusPct(target, "defDebuffPct"), 0, 0.9);
    const defMultiplier = Math.max(0.1, 1 + defBuffPct - defDebuffPct);
    const effectiveTargetDef = Math.max(0, Math.round(originalTargetDef * defMultiplier));

    // Set temporarily for computeEnemyAttack to read
    enemy.attack = effectiveEnemyAtk;
    target.def = effectiveTargetDef;

    // ---- Compute attack (includes DR + shield absorption in damageSystem) ----
    const result = computeEnemyAttack(enemy, target);

    // Restore base stats immediately
    enemy.attack = originalEnemyAtk;
    target.def = originalTargetDef;

    // Accept result
    target.hp = result.newHp;

    const finalDamage = Number(result.damage ?? 0) || 0;
    const who = target.movie.title.slice(0, 10);

    if (result.isCrit) {
      lines.push(`${enemy.name} uses ${move.name}! CRITICAL on ${who} for ${finalDamage}!`);
    } else {
      lines.push(`${enemy.name} uses ${move.name} on ${who} for ${finalDamage}.`);
    }

    // Defend message + clear flag
    if (target.isDefending) {
      lines[lines.length - 1] += ` ${who} guarded the blow.`;
      target.isDefending = false;
    }

    if (target.hp <= 0) {
      lines.push(`${who} is knocked out!`);
    }
  }

  return {
    lines,
    partyDefeated: getAliveParty(party).length === 0
  };
}
