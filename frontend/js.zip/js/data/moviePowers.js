// frontend/js/data/moviePowers.js
//
// DEPRECATED: kept only so older imports don't break.
// The real source of truth is now data/specials.js.

export { specials as moviePowers } from "./specials.js";
