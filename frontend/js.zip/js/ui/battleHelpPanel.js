// frontend/js/ui/battleHelpPanel.js
//
// Battle Help Panel text builder.
// - Shows context help for Actions / Items / Specials.
// - Uses battleText/targets.js for target labels (V2 framework).
//
// ✅ Step B compatibility:
// - Signature specials may store their kind in `sigKind` (legacy: `kind`).
// - Combo rules that check kind must read `sigKind ?? kind`.
//

import { buildTargetLabel } from "../battleText/targets.js";
import { normalizeTargetTags as normalizeTags } from "../systems/specialTags.js";

export const ACTION_DESCRIPTIONS = {
  ATTACK: "Deal damage to the enemy based on this movie's ATK. Can crit.",
  DEFEND: "Brace for impact. Incoming damage is reduced until your next turn.",
  ITEM: "Use an item from your inventory. Some items target allies.",
  SPECIAL: "Open your special moves menu (signature + genre moves).",
  RUN: "Attempt to escape."
};

function defaultGetItemHelpText(entry, getInventoryItemDef) {
  const def = getInventoryItemDef ? getInventoryItemDef(entry) : null;
  if (!def) return "Unknown item.";
  if (def.description) return def.description;

  const name = def.name || "Item";
  const tgt = def.target || "self";
  if (tgt === "ally") return `${name}: choose an ally to use it on.`;
  if (tgt === "self") return `${name}: use on yourself.`;
  return `${name}: use it.`;
}

// ---------------- SPECIAL HELP (TAGS + COMBO RULES) ----------------

function normalizeTargetTags(target) {
  // Step A normalization (lowercase, trims, supports string or array)
  const tags = normalizeTags(target);
  // Keep conservative aliasing for common variations.
  return tags.map((t) => (t === "team_strike" ? "teamstrike" : t));
}

function hasAll(tags, required) {
  for (const r of required) if (!tags.includes(r)) return false;
  return true;
}

function getSpecialKind(sp) {
  // ✅ Signature specials prefer sigKind; keep legacy kind as fallback.
  return String(sp?.sigKind ?? sp?.kind ?? "").trim();
}

function matchesComboRule(sp, tags, rule) {
  if (rule.requires && !hasAll(tags, rule.requires)) return false;

  if (rule.requiresAny && Array.isArray(rule.requiresAny) && rule.requiresAny.length) {
    const ok = rule.requiresAny.some((t) => tags.includes(t));
    if (!ok) return false;
  }

  if (rule.requiresKind) {
    const kinds = Array.isArray(rule.requiresKind) ? rule.requiresKind : [rule.requiresKind];
    const k = getSpecialKind(sp);
    if (!kinds.includes(k)) return false;
  }

  return true;
}

/**
 * Combo rules return a SHORT suffix appended to the description line.
 * Most specific first.
 */
const SPECIAL_HELP_COMBOS = [
  {
    id: "team_teamstrike_buff",
    requires: ["team", "teamstrike", "buff"],
    build() {
      return { bodySuffix: "Then a team strike takes place." };
    }
  },
  {
    id: "team_teamstrike",
    requires: ["team", "teamstrike"],
    build() {
      return { bodySuffix: "A team strike takes place." };
    }
  },
  {
    id: "ally_heal_revive",
    requires: ["ally", "heal", "revive"],
    build() {
      return { bodySuffix: "Revives if down, heals if alive." };
    }
  },
  { id: "ally_revive", requires: ["ally", "revive"], build: () => ({ bodySuffix: "Revives a downed ally." }) },
  { id: "ally_heal", requires: ["ally", "heal"], build: () => ({ bodySuffix: "Heals a chosen ally." }) },
  {
    id: "enemy_fx",
    requires: ["enemy"],
    requiresAny: ["fx", "atkdown", "defdown", "critdown", "vuln", "status", "debuff"],
    build: () => ({ bodySuffix: "Applies an effect." })
  },

  // Base fallbacks
  { id: "team_base", requires: ["team"], build: () => ({ bodySuffix: "Applies an effect to all living allies." }) },
  { id: "self_base", requires: ["self"], build: () => ({ bodySuffix: "Applies an effect to self." }) },
  { id: "ally_base", requires: ["ally"], build: () => ({ bodySuffix: "Choose an ally." }) },
  { id: "enemy_base", requires: ["enemy"], build: () => ({ bodySuffix: "Affects the enemy." }) }
];

function buildComboSuffix(sp) {
  const tags = normalizeTargetTags(sp?.target);
  for (const rule of SPECIAL_HELP_COMBOS) {
    if (matchesComboRule(sp, tags, rule)) {
      const built = rule.build(sp, tags);
      return String(built?.bodySuffix || "").trim();
    }
  }
  return "";
}

function buildQuotedDescriptionLine(sp) {
  const desc = String(sp?.description || "").trim();
  const suffix = buildComboSuffix(sp);

  const parts = [];
  if (desc) parts.push(`"${desc}"`);
  if (suffix) parts.push(suffix);

  if (!parts.length) return `"…"`;
  return parts.join(" ");
}

function defaultGetSpecialHelpText(sp) {
  if (!sp) return "No special selected.";

  const targetSummary = buildTargetLabel(sp);

  const cd = Number(sp.cooldownRemaining || 0);
  const cdText = cd > 0 ? `CD: ${cd}` : "Ready";

  const line1 = buildQuotedDescriptionLine(sp);
  const line2 = `${targetSummary} | ${cdText}`;

  return `${line1}\n${line2}`;
}

function joinHints(hints = []) {
  return hints.length ? hints.join("  |  ") : "";
}

// ---------------- MAIN EXPORT ----------------

export function getBattleHelpPanelText(ctx = {}) {
  const {
    phase,
    uiMode,
    actor,
    isMessageBusy,

    actions = [],
    actionIndex = 0,
    actionDescriptions = ACTION_DESCRIPTIONS,

    confirmAction,

    inventory = [],
    itemIndex = 0,
    getInventoryItemDef,

    pendingItemIndex = -1,
    targetIndex = 0,
    party = [],

    specialsList = [],
    specialIndex = 0,
    pendingSpecial,

    canToggleSpecialPages,
    getSpecialPageCount
  } = ctx;

  if (phase !== "player") return null;
  if (typeof isMessageBusy === "function" && isMessageBusy()) return null;

  const actorName = actor?.movie?.title ? actor.movie.title : actor?.name || "Actor";

  if (uiMode === "confirm") {
    const a = confirmAction || "ACTION";
    return {
      title: `(${actorName}): Confirm ${a}?\nEnter: Confirm  |  Backspace: Back`,
      body: ""
    };
  }

  if (uiMode === "command") {
    const action = actions[actionIndex] || "ACTION";
    return {
      title: `${actorName}: Choose an Action.`,
      body: actionDescriptions[action] || "Choose an action."
    };
  }

  if (uiMode === "item") {
    const entry = inventory[itemIndex];

    const hints = [];
    if (ctx.itemPageCount && ctx.itemPageCount > 1) hints.push("Space: Toggle");
    hints.push("Backspace: Back");

    return {
      title: `(${actorName}): Choose an Item.\n${joinHints(hints)}`,
      body: entry ? defaultGetItemHelpText(entry, getInventoryItemDef) : "No items available."
    };
  }

  if (uiMode === "itemTarget") {
    const entry = pendingItemIndex >= 0 ? inventory[pendingItemIndex] : null;
    const def = entry && getInventoryItemDef ? getInventoryItemDef(entry) : null;
    const itemName = def?.name || "Item";
    const target = party[targetIndex];
    const targetName = target?.movie?.title || target?.name || "Target";
    return {
      title: `(${actorName}): Choose a Target.\nBackspace: Back`,
      body: `${itemName} → ${targetName}`
    };
  }

  if (uiMode === "special") {
    const sp = specialsList[specialIndex];

    const hints = [];
    if (actor && typeof canToggleSpecialPages === "function" && canToggleSpecialPages(actor)) {
      const movieId = actor?.movie?.id;
      const count = typeof getSpecialPageCount === "function" ? getSpecialPageCount(movieId) : 0;
      if (count > 1) hints.push("Space: Toggle");
    }
    hints.push("Backspace: Back");

    const moveName = sp?.name ? sp.name : "Special";

    return {
      title: `(${actorName}): Special — ${moveName}\n${joinHints(hints)}`,
      body: sp ? defaultGetSpecialHelpText(sp) : "No specials available."
    };
  }

  if (uiMode === "specialTarget") {
    const sp = pendingSpecial;
    const moveName = sp?.name ? sp.name : "Special";

    const target = party[targetIndex];
    const targetName = target?.movie?.title || target?.name || "Target";

    return {
      title: `(${actorName}): ${moveName}\nBackspace: Back`,
      body: `${moveName} → ${targetName}`
    };
  }

  return {
    title: `(${actorName}): Choose an Action.`,
    body: "Choose an action."
  };
}
